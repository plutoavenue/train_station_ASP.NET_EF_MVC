﻿using System;

namespace lab_4.Models
{
    public class Passangers
    {
        public Int32 PassengerId { get; set; }

        public string FullName { get; set; }

        public string Address { get; set; }

        public string Phone { get; set; }

    }
}
