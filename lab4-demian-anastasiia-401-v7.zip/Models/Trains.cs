﻿using System;

namespace lab_4.Models
{
    public class Trains
    {
        public Int32 TrainId { get; set; }

        public string Train { get; set; }

        public string TrainType { get; set; }


    }
}
